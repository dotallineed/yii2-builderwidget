<?php

use yii\db\Migration;
use yii\db\Schema;

class m160117_225613_create_builder_widgets_table extends Migration
{
	/**
     *
     */
    public function up()
    {
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        $this->createTable('builder_widgets', [
            'id' => $this->string(255),
            'userid' => $this->integer(20),
            'businesshash' => $this->string(255)->notNull(),
            'name' => $this->string(255)->notNull(),
            'content' => $this->longtext()->notNull(),
            'created_on' => $this->datetime()->notNull(),
            'updated_on' => $this->datetime()->notNull(),
            'content_filtered' => $this->longtext()->notNull(),
            'parent' => $this->integer(20),
			'status' => $this->boolean()->notNull()->defaultValue(1),
            'guid' => $this->string(255),
            'menu_order' => $this->integer(20),
            'type' => $this->string(30)->notNull()->defaultValue('text'),
            'flag' => $this->string(30)->notNull()->defaultValue('text'),  
            'featured_image' => $this->string(255),
            'filename' => $this->string(255),
            'attachment1' => $this->string(255),
            'filename1' => $this->string(255),
            'attachment2' => $this->string(255),
            'filename2' => $this->string(255),
            'attachment3' => $this->string(255),
            'filename3' => $this->string(255),			
            'PRIMARY KEY (id)',
        ],$tableOptions);
    }

	/**
     * @return bool
     */
    public function down()
    {
        echo "m160117_225613_create_builder_widgets_table cannot be reverted.\n";
        $this->dropTable('builder_widgets');
        return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
